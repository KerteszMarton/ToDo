let tasks = JSON.parse(localStorage.getItem("tasks")) || [];

function renderTasks(filter = "all") {
  const taskList = document.getElementById("task-list");
  taskList.innerHTML = "";

  let filteredTasks = tasks;

  if (filter === "done") {
    filteredTasks = tasks.filter((task) => task.done);
  } else if (filter === "pending") {
    filteredTasks = tasks.filter((task) => !task.done);
  }

  filteredTasks.forEach((task, index) => {
    const taskItem = document.createElement("li");
    taskItem.classList.toggle("done", task.done);
    taskItem.setAttribute("data-priority", task.priority);
    taskItem.setAttribute("data-deadline", task.deadline);

    const taskName = document.createElement("span");
    taskName.textContent = `${task.name} (Prioritás: ${task.priority}) -\t Határidő: ${task.deadline}`;

    const markDoneBtn = document.createElement("button");
    markDoneBtn.textContent = task.done ? "Visszavonás" : "Kész";
    markDoneBtn.addEventListener("click", () => toggleTaskDone(index));

    const editBtn = document.createElement("button");
    editBtn.textContent = "Szerkesztés";
    editBtn.addEventListener("click", () => showEditForm(index));

    const deleteBtn = document.createElement("button");
    deleteBtn.textContent = "Törlés";
    deleteBtn.addEventListener("click", () => deleteTask(index));

    taskItem.appendChild(taskName);
    taskItem.appendChild(markDoneBtn);
    taskItem.appendChild(editBtn);
    taskItem.appendChild(deleteBtn);
    taskList.appendChild(taskItem);
  });
}

document.getElementById("add-task").addEventListener("click", () => {
  const name = document.getElementById("task-name").value;
  const priority = document.getElementById("task-priority").value;
  const deadline = document.getElementById("task-deadline").value;

  if (name && deadline) {
    const newTask = { name, priority, deadline, done: false };
    tasks.push(newTask);
    localStorage.setItem("tasks", JSON.stringify(tasks));
    renderTasks();
  }
});

// Toggle task completion
function toggleTaskDone(index) {
  tasks[index].done = !tasks[index].done;
  localStorage.setItem("tasks", JSON.stringify(tasks));
  renderTasks();
}

// Delete task
function deleteTask(index) {
  tasks.splice(index, 1);
  localStorage.setItem("tasks", JSON.stringify(tasks));
  renderTasks();
}

document
  .getElementById("filter-all")
  .addEventListener("click", () => renderTasks("all"));
document
  .getElementById("filter-done")
  .addEventListener("click", () => renderTasks("done"));
document
  .getElementById("filter-pending")
  .addEventListener("click", () => renderTasks("pending"));

document.getElementById("dark-mode-toggle").addEventListener("click", () => {
  document.body.classList.toggle("dark-mode");
});

document
  .getElementById("filter-priority")
  .addEventListener("click", function () {
    var taskList = document.getElementById("task-list");
    var tasks = Array.from(taskList.getElementsByTagName("li"));

    tasks.sort(function (a, b) {
      var priorityA = a.getAttribute("data-priority");
      var priorityB = b.getAttribute("data-priority");

      if (priorityA === "Fontos" && priorityB !== "Fontos") {
        return -1;
      } else if (priorityA !== "Fontos" && priorityB === "Fontos") {
        return 1;
      } else {
        return 0;
      }
    });

    tasks.forEach(function (task) {
      taskList.appendChild(task);
    });
  });

document
  .getElementById("filter-deadline")
  .addEventListener("click", function () {
    var taskList = document.getElementById("task-list");
    var tasks = Array.from(taskList.getElementsByTagName("li"));

    tasks.sort(function (a, b) {
      var deadlineA = new Date(a.getAttribute("data-deadline"));
      var deadlineB = new Date(b.getAttribute("data-deadline"));

      return deadlineA - deadlineB;
    });

    tasks.forEach(function (task) {
      taskList.appendChild(task);
    });
  });

function showEditForm(index) {
  const task = tasks[index];
  const editForm = document.getElementById("edit-form");
  const editTaskInput = document.getElementById("edit-task");
  const editPrioritySelect = document.getElementById("edit-priority");
  const editDateInput = document.getElementById("edit-date");

  editTaskInput.value = task.name;
  editPrioritySelect.value = task.priority;
  editDateInput.value = task.deadline;

  editForm.style.display = "block";

  editForm.dataset.index = index;
}
document.getElementById("edit-form").addEventListener("submit", editTask);
function editTask(event) {
  event.preventDefault();

  const editTaskInput = document.getElementById("edit-task");
  const editPrioritySelect = document.getElementById("edit-priority");
  const editDateInput = document.getElementById("edit-date");

  const taskIndex = parseInt(event.target.dataset.index);

  if (!isNaN(taskIndex) && taskIndex !== -1) {
    const originalTask = tasks[taskIndex];

    const editedTask = {
      name: editTaskInput.value,
      priority: editPrioritySelect.value,
      deadline: editDateInput.value,
      done: originalTask.done,
    };

    tasks[taskIndex] = editedTask;
    localStorage.setItem("tasks", JSON.stringify(tasks));
    hideEditForm();
    renderTasks();
  } else {
    console.error("Érvénytelen feladat index!", taskIndex);
  }
}
function hideEditForm() {
  const editForm = document.getElementById("edit-form");
  editForm.style.display = "none";
}
function checkDeadlines() {
  const now = new Date().toISOString().split("T")[0]; // Today's date in YYYY-MM-DD format
  tasks.forEach((task) => {
    if (task.deadline === now && !task.done) {
      alert(`A/Az "${task.name}" feladat határideje ma járt le!`);
    }
  });
}
// Check deadlines on page load and every day
checkDeadlines();
setInterval(checkDeadlines, 24 * 60 * 60 * 1000); // Check daily

// Initial render
renderTasks();
